package com.iunetworks.enums;

public enum CompanyType {
  CJSC,
  SP
}
