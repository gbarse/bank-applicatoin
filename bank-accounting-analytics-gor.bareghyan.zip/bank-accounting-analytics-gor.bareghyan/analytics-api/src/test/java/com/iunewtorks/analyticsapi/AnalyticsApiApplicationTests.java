package com.iunewtorks.analyticsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyticsApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
