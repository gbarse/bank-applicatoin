package com.iunetworks.enums;

public enum AccountAndCardStatus {
  ACTIVE,
  DISABLED,
  IN_PROCESS,
  REJECTED
}
