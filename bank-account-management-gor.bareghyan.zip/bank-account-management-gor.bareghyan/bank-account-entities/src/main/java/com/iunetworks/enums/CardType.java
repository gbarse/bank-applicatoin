package com.iunetworks.enums;

public enum CardType {
  STANDARD,
  VISA,
  MASTERCARD
}

