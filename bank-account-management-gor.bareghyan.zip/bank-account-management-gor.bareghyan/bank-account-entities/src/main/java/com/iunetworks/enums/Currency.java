package com.iunetworks.enums;

public enum Currency {
  AMD,
  USD,
  EUR,
  RUB,
  GEL
}
