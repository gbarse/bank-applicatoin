package com.iunetworks.enums;

public enum CardLevel {
  CLASSIC,
  GOLD,
  PLATINUM
}

